<?php
    if(isset($_POST['Submit'])){
        $Email = $_POST['Email'];
        echo "Email is " . $Email;
    }
?>


<!DOCTYPE html>
<html lang="en">
<head>
    
</head>
<body>
    <fieldset>
    <legend>EMAIL</legend>
        Email <br>
        <form action="" method="post">
            <input type="text" name="Email"> 
            <input type="Submit"  value="i" title="hint: example@example.com">
            <br>
            <input type="Submit" name="Submit" value="Submit" id="">
        </form>
    </fieldset>
</body>
</html>