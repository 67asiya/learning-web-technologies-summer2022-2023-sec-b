<?php
    $Email = $_POST['Email'];
    echo "Email is " . $Email;
?>