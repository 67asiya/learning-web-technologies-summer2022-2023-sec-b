<?php
    $Email = '';
    if(isset($_POST['Submit'])){
        $email = $_POST['Email'];
        echo "Email is " . $email;
    }
?>


<!DOCTYPE html>
<html lang="en">
<head>
    
</head>
<body>
    <fieldset>
        <legend>EMAIL</legend>
        Email <br>
        <form action="" method="post">
            <input type="text" name="Email" value="i"<?php echo $Email ?>"> 
            <input type="submit"  value="" title="hint: example@example.com">
            <br>
            <input type="Submit" name="Submit" value="Submit" id="">
        </form>
    </fieldset>
</body>
</html>