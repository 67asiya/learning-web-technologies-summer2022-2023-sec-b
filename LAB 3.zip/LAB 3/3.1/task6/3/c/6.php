<?php
    $Group = '';
    if(isset($_POST['Submit'])){
        $Group = $_POST['Group'];
        echo " Blood group  {$Group}";
    }
?>

<!DOCTYPE html>
<html lang="en">
<head>
    
</head>
<body>
    <form action="" method="post">
        Blood Group &nbsp;
        <select name="group" id="" >
            <option value="A+" <?php if($Group=='A+') echo 'selected' ?>>A+</option>
            <option value="A-" <?php if($Group=='A-') echo 'selected' ?>>A-</option>
            <option value="AB+" <?php if($Group=='AB+') echo 'selected' ?>>AB+</option>
            <option value="B+" <?php if($Group=='B+') echo 'selected' ?>>B+</option>
            <option value="B-" <?php if($Group=='B-') echo 'selected' ?>>B-</option>
        </select>
        <hr>
        <input type="Submit" value="Submit" name="Submit">
    </form>
</body>
</html>