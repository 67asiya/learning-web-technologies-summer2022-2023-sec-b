<?php
    $Group = $_POST['Group'];
    echo " Blood group {$Group}";
?>