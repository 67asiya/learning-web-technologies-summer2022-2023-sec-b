<?php
    if(isset($_POST['Submit'])){
        $Group = $_POST['Group'];
        echo "Blood group {$Group}";
    }
?>

<!DOCTYPE html>
<html lang="en">
<head>
    
</head>
<body>
    <form action="" method="post">
        
        Blood Group &nbsp;
        <select name="Group" id="" >
            <option value="A+">A+</option>
            <option value="A-">A-</option>
            <option value="AB+">AB+</option>
            <option value="B+">B+</option>
            <option value="B-">B-</option>
        </select>
        <hr>
        <input type="Submit" value="Submit" name="Submit">
    </form>
</body>
</html>