<?php
echo $_POST["Name"];
?>