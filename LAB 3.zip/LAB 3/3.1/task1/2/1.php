<?php
if(isset( $_POST["Submit"])){
    echo $_POST["Name"];
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    
</head>
<body>
   <form action="" method="post">
     Name <br>
    <input type="text" name="Name"> <br>
    <input type="submit" value="submit" name="Submit" id="">
   </form>
</body>
</html>