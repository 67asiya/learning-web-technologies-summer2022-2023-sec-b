<?php
    $gender = $_POST['Gender'];
    echo " Gender is " . $gender;
   
?>