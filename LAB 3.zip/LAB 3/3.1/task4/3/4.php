<?php
    $Gender = '';
   if(isset($_POST['Submit'])){
        $gender = $_POST['Gender'];
        echo " Gender is " . $Gender;
   }
?>

<!DOCTYPE html>
<html lang="en">
<head>
    
</head>
<body>
    <form action="" method="post">
        <fieldset>
            <legend>Gender</legend>
            <input type="radio" name="Gender" value="Male" <?php if($gender == 'Male') echo 'checked' ?>> Male
            <input type="radio" name="Gender" value="Female" <?php if($gender == 'Female') echo 'checked' ?>> Female
            <input type="radio" name="Gender" value="Other" <?php if($gender == 'Other') echo 'checked' ?>> Other
        </fieldset>
        <input type="Submit" name="Submit" value="Submit">
    </form>
</body>
</html>