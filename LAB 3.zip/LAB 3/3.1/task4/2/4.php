
<?php
   if(isset($_POST['Submit'])){
        $gender = $_POST['Gender'];
        echo "Gender is " . $gender;
   }
?>

<!DOCTYPE html>
<html lang="en">
<head>
    
</head>
<body>
    <form action="" method="post">
        <fieldset>
            <legend>Gender</legend>
            <input type="radio" name="Gender" value="Male"> Male
            <input type="radio" name="Gender" value="Female"> Female
            <input type="radio" name="Gender" value="Other"> Other
        </fieldset>
        <input type="Submit" name="Submit" value="Submit" >
    </form>
</body>
</html>
