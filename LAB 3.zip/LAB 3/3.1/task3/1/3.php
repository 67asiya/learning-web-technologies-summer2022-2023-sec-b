<?php
   $Date= $_POST['Date'];
   $Month= $_POST['Month'];
   $Year= $_POST['Year'];

   echo "Date:{$Date}/{$Month}/{$Year}";

?>