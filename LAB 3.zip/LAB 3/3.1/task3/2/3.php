<?php
   if(isset($_POST['Submit']))
  { $Date= $_POST['Date'];
    $Month= $_POST['Month'];
    $Year= $_POST['Year'];
 
    echo "Date:{$Date}/{$Month}/{$Year}";
 }
?>
<!DOCTYPE html>
<html lang="en">
<head>
    
</head>
<body>
    <fieldset>
        <form action="" method="post">
        <legend>Date of Birth</legend>
        &nbsp; dd &nbsp; &nbsp; &nbsp; mm   &nbsp;yyyy <br>
        <input type="text" name=" Date"size="1"> /
        <input type="text" name="Month"size="1"> /
        <input type="text" name="Year" size="1">
        <hr>
        <input type="Submit" value="Submit" name="Submit">
      </form>
    </fieldset>
    
</body>
</html>