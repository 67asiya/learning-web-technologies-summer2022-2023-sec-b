<?php
    if(isset($_POST['Submit'])){
        $ssc = $hsc = $bsc = $msc = '';
        if(isset($_POST['SSC'])) $ssc = $_POST['SSC'];
        if(isset($_POST['HSC'])) $hsc = $_POST['HSC'];
        if(isset($_POST['BSc'])) $bsc = $_POST['BSc'];
        if(isset($_POST['MSc'])) $msc = $_POST['MSc'];

        echo " Degree(s) are {{$ssc} {$hsc} {$bsc} {$msc}}";
    }
?>

<!DOCTYPE html>
<html lang="en">
<head>
    
</head>
<body>
    <form action="" method="post">
        <fieldset>
            <legend>Degree</legend>
            <input type="checkbox" name="SSC" value="SSC" size="1"> SSC
            <input type="checkbox" name="HSC" value="HSC" size="1"> HSC
            <input type="checkbox" name="BSc" value="BSc" size="1"> BSc
            <input type="checkbox" name="MSc" value="MSc" size="1"> MSc
        </fieldset>
        <input type="Submit" name="Submit" value="Submit" id="">
    </form>
</body>
</html>