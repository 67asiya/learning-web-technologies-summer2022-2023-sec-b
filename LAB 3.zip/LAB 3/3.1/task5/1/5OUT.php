<?php
    $ssc = $hsc = $bsc = $msc = '';
    if(isset($_POST['ssc'])) $ssc = $_POST['SSC'];
    if(isset($_POST['hsc'])) $hsc = $_POST['HSC'];
    if(isset($_POST['bsc'])) $bsc = $_POST['BSC'];
    if(isset($_POST['msc'])) $msc = $_POST['MSC'];

    echo "Degree(s) are {{$ssc} {$hsc} {$bsc} {$msc}}";
?>