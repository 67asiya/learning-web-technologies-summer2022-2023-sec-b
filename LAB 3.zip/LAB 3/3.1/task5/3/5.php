<?php
    $ssc = $hsc = $bsc = $msc = '';
    if(isset($_POST['submit'])){
        
        if(isset($_POST['SSC'])) $ssc = $_POST['SSC'];
        if(isset($_POST['HSC'])) $hsc = $_POST['HSC'];
        if(isset($_POST['BSC'])) $bsc = $_POST['BSC'];
        if(isset($_POST['MSC'])) $msc = $_POST['MSC'];

        echo " Degree(s) are {{$ssc} {$hsc} {$bsc} {$msc}}";
    }
?>

<!DOCTYPE html>
<html lang="en">
<head>
    
</head>
<body>
    <form action="" method="post">
        <fieldset>
            <legend>Degree</legend>
            <input type="checkbox" name="SSC" value="SSC" <?php if($ssc=='SSC') echo 'checked' ?> size="1"> SSC
            <input type="checkbox" name="HSC" value="HSC" <?php if($hsc=='HSC') echo 'checked' ?> size="1"> HSC
            <input type="checkbox" name="HSC" value="BSc" <?php if($bsc=='BSc') echo 'checked' ?> size="1"> BSc
            <input type="checkbox" name="MSC" value="MSc" <?php if($msc=='MSc') echo 'checked' ?> size="1"> MSc
        </fieldset>
        <input type="submit" name="submit" value="submit" id="">
    </form>
</body>
</html>