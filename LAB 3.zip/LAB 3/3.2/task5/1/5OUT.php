<?php
    $ssc = $hsc = $bsc = $msc = '';
    count=0;
    if(isset($_POST['ssc'])) {$ssc = $_POST['SSC'] $count++};
    if(isset($_POST['hsc'])) {$hsc = $_POST['HSC'] $count++};
    if(isset($_POST['bsc'])) {$bsc = $_POST['BSC'] $count++};
    if(isset($_POST['msc'])) {$msc = $_POST['MSC'] $count++};
    if($count < 2) {
        echo '2 box must be selected';
        return;
    }


    echo "Degree(s) are {{$ssc} {$hsc} {$bsc} {$msc}}";
?>