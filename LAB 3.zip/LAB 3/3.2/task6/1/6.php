<?php
 if(!isset($_POST['group'])){
    echo 'Must be selected one';
    return;
 }
    $Group = $_POST['Group'];
    echo " Blood group {$Group}";
?>